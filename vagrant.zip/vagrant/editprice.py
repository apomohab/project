from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database_setup import Base, Restaurant, MenuItem

engine = create_engine('sqlite:///restaurantmenu.db')

Base.metadata.bind = engine

DBsession = sessionmaker(bind = engine)

session = DBsession()

info = session.query(MenuItem).all()

for data in info :

    print data.name

print "*********************************************************************"
print "print the item chese pizza only"

pizza = session.query(MenuItem).filter_by(name = 'Cheese Pizza')

for pizzaprice in pizza :

    print pizzaprice.id
    print pizzaprice.price
    print pizzaprice.restaurant.name
    print "\n"


print "*********************************************************************"
print "know the price for chese pizza only"

pizza_place = session.query(MenuItem).filter_by(id = 1).one()

print pizza_place.price


print "*********************************************************************"
print "Now edit the price"

pizza_place.price = "10"
session.add(pizza_place)
session.commit()

print pizza_place.price

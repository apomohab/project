#first database in 2-5-2.19
import os
import sys
from sqlalchemy import Column,ForeignKey,Integer,String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine

Base = declarative_base()

class Factory(Base):

    __tablename__= 'factory'

    id = Column(Integer, primary_key = True)
    name = Column(String(80), nullable = False)



class Employes(Base):

    __tablename__ = 'employes'

    id = Column(Integer, primary_key = True)
    name = Column(String(80),nullable = False)
    age  = Column(Integer())
    job = Column(String(25))
    country = Column(String(25))
    factory_id = Column(Integer, ForeignKey('factory.id'))
    factory = relationship(Factory) 


engine = create_engine('sqlite:///technobond.db')

Base.metadata.create_all(engine)